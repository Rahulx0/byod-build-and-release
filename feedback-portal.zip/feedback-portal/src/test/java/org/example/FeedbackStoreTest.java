package org.example;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class FeedbackStoreTest {

    @AfterEach
    void afterEach() {
        FeedbackStore.clear();
    }

    @Test
    void addValidFeedbackIncreasesCountAndIsRetrievable() {
        boolean added = FeedbackStore.addFeedback("Great course!");
        assertTrue(added);
        List<FeedbackEntry> all = FeedbackStore.getAllFeedbacks();
        assertEquals(1, all.size());
        assertEquals("Great course!", all.get(0).getText());
    }

    @Test
    void addingEmptyOrBlankFeedbackIsRejected() {
        assertFalse(FeedbackStore.addFeedback(""));
        assertFalse(FeedbackStore.addFeedback("   "));
        assertEquals(0, FeedbackStore.getCount());
    }
}

