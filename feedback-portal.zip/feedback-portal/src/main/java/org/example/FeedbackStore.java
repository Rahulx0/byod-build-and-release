package org.example;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FeedbackStore {
    private static final List<FeedbackEntry> feedbacks =
            Collections.synchronizedList(new ArrayList<>());

    public static boolean addFeedback(String feedback) {
        if (feedback == null) return false;
        String trimmed = feedback.trim();
        if (trimmed.isEmpty()) return false;
        feedbacks.add(new FeedbackEntry(trimmed, Instant.now()));
        return true;
    }

    public static List<FeedbackEntry> getAllFeedbacks() {
        synchronized (feedbacks) {
            return new ArrayList<>(feedbacks);
        }
    }
    public static int getCount() {
        return feedbacks.size();
    }

    public static void clear() {
        feedbacks.clear();
    }
}

