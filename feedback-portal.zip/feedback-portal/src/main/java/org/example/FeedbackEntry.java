package org.example;

import java.time.Instant;

public class FeedbackEntry {
    private final String text;
    private final Instant timestamp;

    public FeedbackEntry(String text, Instant timestamp) {
        this.text = text;
        this.timestamp = timestamp;
    }

    public String getText() {
        return text;
    }

    public Instant getTimestamp() {
        return timestamp;
    }
}

